package com.gredicer.camerastudy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.gredicer.camerastudy.base.BaseBindingActivity
import com.gredicer.camerastudy.databinding.ActivityCameraBinding

class Camera2Activity : BaseBindingActivity<ActivityCameraBinding>() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
}